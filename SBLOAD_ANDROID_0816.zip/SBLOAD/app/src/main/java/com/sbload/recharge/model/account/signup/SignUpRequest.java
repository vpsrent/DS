package com.sbload.recharge.model.account.signup;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.CommonResponse;
import com.sbload.recharge.model.BaseRequest;
import com.sbload.recharge.utility.APIUtility;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignUpRequest extends BaseRequest {

    private String deviceId;
    private String name;
    private String mobile;
    private String email;

    public SignUpRequest(String deviceId, String name, String mobile, String email) {
        this.deviceId = deviceId;
        this.name = name;
        this.mobile = mobile;
        this.email = email;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public String getName() {
        return name;
    }

    public String getMobile() {
        return mobile;
    }

    public String getEmail() {
        return email;
    }

    public void post(final APIUtility.APIResponse<CommonResponse> apiResponse,
                     final CommonExecutive executive) {

        accountService.register(deviceId, name, mobile, email).enqueue(new Callback<CommonResponse>() {
            @Override
            public void onResponse(Call<CommonResponse> call, Response<CommonResponse> response) {
                if (!executive.validateResponse(response)) {
                    apiResponse.onResponse(null);
                    return;
                }

                apiResponse.onResponse(response.body());
            }

            @Override
            public void onFailure(Call<CommonResponse> call, Throwable t) {
                executive.display.showError(R.string.request_failed);
                apiResponse.onResponse(null);
            }
        });
    }
}
