package com.sbload.recharge.executive.service;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.payment.GetPaymentsRequest;
import com.sbload.recharge.model.payment.GetPaymentsResponse;
import com.sbload.recharge.model.payment.TransferLog;
import com.sbload.recharge.model.service.GetPackageOperatorsRequest;
import com.sbload.recharge.model.service.GetPackageOperatorsResponse;
import com.sbload.recharge.model.service.PackageOperator;
import com.sbload.recharge.utility.APIUtility;

import java.util.ArrayList;

public class PackageOperatorExecutive extends CommonExecutive {
    PackageOperatorDisplay display;
    private ArrayList<PackageOperator> packageOperators = new ArrayList<>();
    private PackageOperator selectedOperator = null;

    public PackageOperatorExecutive(PackageOperatorDisplay display) {
        super(display);
        this.display = display;
    }

    public void didSelectOperator(int position) {
        if (packageOperators.isEmpty()) {
            return;
        }
        selectedOperator = packageOperators.get(position);
    }

    public void didPressSubmit() {
        display.gotoSelectPackage(selectedOperator);
    }

    public void getOperators() {
        GetPackageOperatorsRequest request = new GetPackageOperatorsRequest();
        display.showLoading(true);
        request.post(new APIUtility.APIResponse<GetPackageOperatorsResponse>() {
            @Override
            public void onResponse(GetPackageOperatorsResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }

                packageOperators = response.getPackageOperators();
                selectedOperator = packageOperators.get(0);
                display.didGetOperators(packageOperators);
            }
        }, this);
    }



    public interface PackageOperatorDisplay extends CommonDisplay {
        void didGetOperators(ArrayList<PackageOperator> operators);
        void gotoSelectPackage(PackageOperator packageOperator);
    }
}
