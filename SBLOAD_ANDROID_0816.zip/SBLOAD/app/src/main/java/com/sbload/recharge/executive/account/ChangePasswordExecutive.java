package com.sbload.recharge.executive.account;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.CommonResponse;
import com.sbload.recharge.model.account.changepassword.ChangePasswordRequest;
import com.sbload.recharge.utility.APIUtility;

public class ChangePasswordExecutive extends CommonExecutive {
    ChangePasswordDisplay display;

    public ChangePasswordExecutive(ChangePasswordDisplay display) {
        super(display);
        this.display = display;
    }

    public void changePassword() {
        ChangePasswordRequest request = display.getForgotPasswordRequest();
        if (request == null) {
            return;
        }

        int validateString = validateChangePasswordRequest(request);
        if (validateString != R.string.input_validate) {
            display.showError(validateString);
            return;
        }

        display.showLoading(true);
        request.post(new APIUtility.APIResponse<CommonResponse>() {
            @Override
            public void onResponse(CommonResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }
                display.showSuccess(R.string.reset_password_success);
                display.passwordChanged();
            }
        }, this);
    }

    public int validateChangePasswordRequest(ChangePasswordRequest request) {
        if (request.getUsername().isEmpty()) {
            return R.string.empty_user_name;
        }

        if (request.getPassword().isEmpty()) {
            return R.string.empty_password;
        }

        if (request.getNewPassword().isEmpty()) {
            return R.string.empty_new_password;
        }

        return R.string.input_validate;
    }

    public interface ChangePasswordDisplay extends CommonExecutive.CommonDisplay {
        public void passwordChanged();
        public ChangePasswordRequest getForgotPasswordRequest();
    }
}
