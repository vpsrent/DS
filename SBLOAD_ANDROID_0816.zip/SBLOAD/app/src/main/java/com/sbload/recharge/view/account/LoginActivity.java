package com.sbload.recharge.view.account;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.widget.AppCompatEditText;
import android.view.View;

import com.google.gson.Gson;
import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.common.Constants;
import com.sbload.recharge.executive.account.LoginExecutive;
import com.sbload.recharge.model.account.login.LoginRequest;
import com.sbload.recharge.utility.StringUtility;
import com.sbload.recharge.view.BaseActivity;
import com.sbload.recharge.view.container.ContainerActivity;

public class LoginActivity extends BaseActivity implements View.OnClickListener, LoginExecutive.LoginDisplay {

    private AppCompatEditText editName, editPassword;
    private LoginExecutive executive;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //
        // Bind controls
        //

        editName = findViewById(R.id.edit_name);
        editPassword = findViewById(R.id.edit_password);

        //
        // Bind events
        //

        findViewById(R.id.btn_login).setOnClickListener(this);
        findViewById(R.id.btn_create_account).setOnClickListener(this);
        findViewById(R.id.btn_forgot_password).setOnClickListener(this);


        executive = new LoginExecutive(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_login:
                executive.login();
                break;
            case R.id.btn_create_account:
                showActivity(SignUpActivity.class, Constants.ANIMATION_BOTTOM_TO_UP, false);
                break;
            case R.id.btn_forgot_password:
                showActivity(ForgotPasswordActivity.class, Constants.ANIMATION_BOTTOM_TO_UP, false);
                break;
        }
    }

    @Override
    public void onLoginSuccess(boolean twoStepRequire) {
        if (twoStepRequire) {
            showActivity(VerifyCodeActivity.class, Constants.ANIMATION_BOTTOM_TO_UP, false);
            return;
        }

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor editor =
                preferences.edit();
        editor.putInt("SBLoad_Logged_In", 1);
        editor.putString("SBLoad_AppData", new Gson().toJson(AppData.user));
        editor.commit();
        showActivity(ContainerActivity.class, Constants.ANIMATION_BOTTOM_TO_UP, false);
    }

    @Override
    public LoginRequest getLoginRequest() {
        return new LoginRequest(StringUtility.deviceId(getApplicationContext()),
                editName.getText().toString(),
                editPassword.getText().toString());
    }
}
