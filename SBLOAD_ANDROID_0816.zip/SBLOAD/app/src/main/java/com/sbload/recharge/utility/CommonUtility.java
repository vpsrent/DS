package com.sbload.recharge.utility;

import android.content.Context;
import android.graphics.drawable.Drawable;

import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CommonUtility {
    public static Drawable serviceDrawableFromAssets(Context context, String logo) {
        String assetPath = "services/" + logo + ".png";
        Drawable drawable;
        try
        {
            InputStream ims = context.getAssets().open(assetPath);
            drawable = Drawable.createFromStream(ims, null);
            ims .close();
            return drawable;
        }
        catch(IOException ex)
        {
            return null;
        }
    }

    public static float stringToFloat(String str) {
        return stringToFloat(str, 0.f);
    }

    public static float stringToFloat(String str, Float defaultValue)
    {
        try
        {
            float f = Float.valueOf(str.trim()).floatValue();
            return f;
        }
        catch (NumberFormatException nfe)
        {
            return defaultValue;
        }
    }

    public static String ChangeDateFormat(String dateStr, String fromFormat, String toFormat) {
        Date date = CommonUtility.StringToDate(dateStr, fromFormat);
        return DateToString(date, toFormat);
    }

    public static String DateToString(Date date, String format) {
        DateFormat dateFormat = new SimpleDateFormat(format);
        String dateStr = dateFormat.format(date);
        return dateStr;
    }

    public static Date StringToDate(String dateStr, String format) {
        try {
            Date date = new SimpleDateFormat(format).parse(dateStr);
            return date;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }


}
