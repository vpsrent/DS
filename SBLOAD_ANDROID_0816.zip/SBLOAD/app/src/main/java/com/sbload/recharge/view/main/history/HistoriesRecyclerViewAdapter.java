package com.sbload.recharge.view.main.history;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Switch;

import com.sbload.recharge.R;
import com.sbload.recharge.model.service.ServiceRequest;
import com.sbload.recharge.utility.CommonUtility;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class HistoriesRecyclerViewAdapter extends RecyclerView.Adapter<HistoriesRecyclerViewAdapter.ViewHolder> {
    HistoryRecyclerItemEventListener listener;

    private ArrayList<ServiceRequest> histories = new ArrayList<>();
    private Context context;
    HistoriesRecyclerViewAdapter(Context context, HistoryRecyclerItemEventListener listener) {
        super();
        this.context = context;
        this.listener = listener;
    }


    public void setHistories(ArrayList<ServiceRequest> histories) {
        this.histories = histories;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_history, parent, false);
        return new HistoriesRecyclerViewAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final ServiceRequest history = histories.get(position);
        Integer type = history.getType();
        Integer serviceId = history.getServiceId();
        int serviceAsset = 0;
        switch (serviceId) {
            case 1:
                serviceAsset = R.drawable.sms;
                break;
            case 2:
                serviceAsset = R.drawable.prepaidcard;
                break;
            case 4:
                serviceAsset = R.drawable.billpay;
                break;
            case 8:
                serviceAsset = R.drawable.flexiload;
                break;
            case 16:
                serviceAsset = R.drawable.bulk_flexi;
                break;
            case 32:
                serviceAsset = R.drawable.bkash;
                break;
            case 64:
                serviceAsset = R.drawable.dbbl;
                break;
            case 128:
                serviceAsset = R.drawable.mcash;
                break;
            case 256:
                serviceAsset = R.drawable.ucash;
                break;
            case 512:
                serviceAsset = R.drawable.intopup;
                break;
            case 1024:
                serviceAsset = R.drawable.nogod;
                break;
        }
        holder.serviceImageView.setImageResource(serviceAsset);

        String cashType = "";
        switch (serviceId) {
            case 8:
            case 512:
                cashType = type == 0 ? "PrePaid" : "PostPaid";
                break;
            case 32:
            case 64:
                if (type == 0) {
                    cashType = "Cash In";
                }
                else if (type == 1) {
                    cashType = "Cash Out";
                }
                else if (type == 2) {
                    cashType = "Send Money";
                }
                else if (type == 3) {
                    cashType = "Payment";
                }
            case 1:
                break;

        }
        holder.firstRowTextView.setText(history.getReceiver() + "(" +
                cashType + ")");
        holder.dateTextView.setText(CommonUtility.ChangeDateFormat(history.getUpdateDate(),
                "yyyy-MM-dd hh:mm:ss", "MMM dd"));
        holder.secondRowTextView.setText(String.format("Amount: %d - Cost: %.2f - Bal: %.2f",
                (int)history.getAmount(), history.getCost(), history.getBalance()));
        holder.thirdRowTextView.setText("TrxID: " + history.getTransactionId());
        holder.statusTextView.setText(history.getStatus() == 0 ? "Success" : "Cancelled");
        if (history.getStatus() == 0) {
            holder.statusTextView.setTextColor(context.getResources().getColor(R.color.dark_green));
        }
        else {
            holder.statusTextView.setTextColor(context.getResources().getColor(R.color.dark_red));
        }
    }

    @Override
    public int getItemCount() {
        return histories.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageView serviceImageView;
        final AppCompatTextView firstRowTextView, dateTextView, secondRowTextView;
        final AppCompatTextView thirdRowTextView, statusTextView;

        ViewHolder(View view) {
            super(view);

            serviceImageView = view.findViewById(R.id.service_image);
            firstRowTextView = view.findViewById(R.id.txt_first_row);
            dateTextView = view.findViewById(R.id.txt_date);
            secondRowTextView = view.findViewById(R.id.txt_second_row);
            thirdRowTextView = view.findViewById(R.id.txt_third_row);
            statusTextView = view.findViewById(R.id.txt_status);
        }
    }

    public interface HistoryRecyclerItemEventListener {
//        public void didClickEdit(Reseller reseller, int position);
    }
}
