package com.sbload.recharge.executive.account;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.CommonResponse;
import com.sbload.recharge.model.account.pin.VerifyPINRequest;
import com.sbload.recharge.utility.APIUtility;
import com.sbload.recharge.utility.StringUtility;

public class VerifyCodeExecutive extends CommonExecutive {
    VerifyCodeDisplay display;

    public VerifyCodeExecutive(VerifyCodeDisplay display) {
        super(display);
        this.display = display;
    }

    public void verifyCode() {
        VerifyPINRequest request = display.getVerifyPINRequest();
        if (request == null) {
            return;
        }

        int validateString = validateVerifyPINRequest(request);
        if (validateString != R.string.input_validate) {
            display.showError(validateString);
            return;
        }

        display.showLoading(true);
        request.post(new APIUtility.APIResponse<CommonResponse>() {
            @Override
            public void onResponse(CommonResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }
                display.onSuccessVerifyPIN();
            }
        }, this);
    }

    public int validateVerifyPINRequest(VerifyPINRequest request) {
        if (request.getPin().isEmpty()) {
            return R.string.empty_pin;
        }

        return R.string.input_validate;
    }

    public interface VerifyCodeDisplay extends CommonExecutive.CommonDisplay {
        public void onSuccessVerifyPIN();
        public VerifyPINRequest getVerifyPINRequest();
    }
}
