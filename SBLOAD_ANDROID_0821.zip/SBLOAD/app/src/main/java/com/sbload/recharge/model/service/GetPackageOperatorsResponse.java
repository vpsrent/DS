package com.sbload.recharge.model.service;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.sbload.recharge.model.CommonResponse;
import com.sbload.recharge.model.region.Country;

import java.util.ArrayList;

public class GetPackageOperatorsResponse extends CommonResponse {

    @SerializedName("response")
    @Expose
    public ArrayList<PackageOperator> packageOperators;

    public ArrayList<PackageOperator> getPackageOperators() {
        return packageOperators;
    }
}
