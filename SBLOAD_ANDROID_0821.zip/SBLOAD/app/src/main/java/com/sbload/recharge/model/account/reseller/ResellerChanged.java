package com.sbload.recharge.model.account.reseller;

public interface ResellerChanged {
    void resellerChanged();
}
