package com.sbload.recharge.model.service;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ServicePackage {

    @SerializedName("id")
    @Expose
    private Integer packageId;

    @SerializedName("opt")
    @Expose
    private Integer operatorId;

    @SerializedName("title")
    @Expose
    private String title;

    @SerializedName("amount")
    @Expose
    private float amount;

    @SerializedName("enable")
    @Expose
    private Integer enable;

    public Integer getPackageId() {
        return packageId;
    }

    public Integer getOperatorId() {
        return operatorId;
    }

    public String getTitle() {
        return title;
    }

    public float getAmount() {
        return amount;
    }

    public Integer getEnable() {
        return enable;
    }
}
