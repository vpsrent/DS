package com.sbload.recharge.view;

import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Message;
import android.os.Bundle;
import android.preference.PreferenceManager;

import com.google.gson.Gson;
import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.common.Constants;
import com.sbload.recharge.executive.SplashExecutive;
import com.sbload.recharge.model.Reseller;
import com.sbload.recharge.view.account.DomainActivity;
import com.sbload.recharge.view.account.LoginActivity;
import com.sbload.recharge.view.container.ContainerActivity;

public class SplashActivity extends BaseActivity implements SplashExecutive.SplashDisplay {

    final int ACTION_GO_TO_LOGIN = 1;
    final int SPLASH_DELAY_TIME = 2500;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == ACTION_GO_TO_LOGIN) {

                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
//                int domainPassed = preferences.getInt("SBLoad_Domain_Passed", 0);
                int domainPassed = 1;
                if (domainPassed == 1) {
                    int loggedIn = preferences.getInt("SBLoad_Logged_In", 0);
                    if (loggedIn == 1) {
                        AppData.user = new Gson().fromJson(preferences.getString("SBLoad_AppData", null), Reseller.class);
                        executive.getUser();
                        return;
                    }
                    showActivity(LoginActivity.class, Constants.ANIMATION_BOTTOM_TO_UP, true);
                    return;
                }
                showActivity(DomainActivity.class, Constants.ANIMATION_BOTTOM_TO_UP, true);
            }
        }
    };

    private SplashExecutive executive;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        executive = new SplashExecutive(this);
        mHandler.sendEmptyMessageDelayed(ACTION_GO_TO_LOGIN, SPLASH_DELAY_TIME);
    }

    @Override
    public void onAutoLogin(boolean isSuccess) {
        if (isSuccess) {
            showActivity(ContainerActivity.class, Constants.ANIMATION_BOTTOM_TO_UP, true);
            return;
        }

        showActivity(LoginActivity.class, Constants.ANIMATION_BOTTOM_TO_UP, true);
    }
}
