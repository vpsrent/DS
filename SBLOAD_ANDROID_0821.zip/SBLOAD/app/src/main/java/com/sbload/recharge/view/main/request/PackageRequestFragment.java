package com.sbload.recharge.view.main.request;


import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatRadioButton;
import android.support.v7.widget.AppCompatTextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import com.google.gson.Gson;
import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.executive.service.PackageRequestExecutive;
import com.sbload.recharge.executive.service.ServiceRequestExecutive;
import com.sbload.recharge.model.account.pin.VerifyPINRequest;
import com.sbload.recharge.model.region.Country;
import com.sbload.recharge.model.region.Operator;
import com.sbload.recharge.model.service.DashboardItem;
import com.sbload.recharge.model.service.PackageOperator;
import com.sbload.recharge.model.service.ServicePackage;
import com.sbload.recharge.model.service.ServiceRequest;
import com.sbload.recharge.model.service.ServiceRequestRequest;
import com.sbload.recharge.utility.CommonUtility;
import com.sbload.recharge.view.BaseFragment;

import java.util.ArrayList;

public class PackageRequestFragment extends BaseFragment implements View.OnClickListener, PackageRequestExecutive.PackageRequestDisplay, ServiceRequestExecutive.ServiceRequestDisplay {

    private static final String ARG_DASHBOARD_ITEM = "arg_dashboard_item";
    private AppCompatEditText numberEditText;
    private AppCompatTextView operatorNameTextView, packageDetailTextView, amountTextView;
    private AppCompatRadioButton prepaidRadioButton;
    private PackageRequestExecutive executive;
    private ServiceRequestExecutive requestExecutive;
    public PackageOperator packageOperator;
    public ServicePackage servicePackage;

    public PackageRequestFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public String getTagName() {
        return PackageRequestFragment.class.getCanonicalName();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_package_request, container, false);

        //
        // Bind controls
        //

        numberEditText = view.findViewById(R.id.edit_mobile);
        prepaidRadioButton = view.findViewById(R.id.radio_prepaid);
        operatorNameTextView = view.findViewById(R.id.txt_operator_name);
        operatorNameTextView.setText("Operator Name: " + packageOperator.getTitle());
        packageDetailTextView = view.findViewById(R.id.txt_package_details);
        packageDetailTextView.setText("Package Details: " + servicePackage.getTitle());
        amountTextView = view.findViewById(R.id.txt_amount);
        amountTextView.setText("Amount: " + String.format("%.2f", servicePackage.getAmount()));

        //
        // Define Events
        //

        view.findViewById(R.id.btn_send).setOnClickListener(this);
        view.findViewById(R.id.btn_back).setOnClickListener(this);

        executive = new PackageRequestExecutive(this);
        requestExecutive = new ServiceRequestExecutive(this);

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_back:
                popBackStack();
                break;
            case R.id.btn_send:
                if (requestExecutive.validatePackageParameters()) {
                    VerifyRequestFragment fragment = new VerifyRequestFragment();
                    fragment.requestExecutive = requestExecutive;
                    fragment.servicePackage = servicePackage;
                    fragment.packageOperator = packageOperator;
                    addContent(fragment);
                }
                break;
        }
    }

    @Override
    public ServiceRequestRequest getServiceRequestRequest() {
        return new ServiceRequestRequest(AppData.user.getUserId(), 10,
                numberEditText.getText().toString(),
                servicePackage.getAmount(),
                prepaidRadioButton.isChecked() ? 0 : 1, -1,
                -1, 1, servicePackage.getPackageId());
    }

    @Override
    public VerifyPINRequest getVerifyPINRequest() {
        return null;
    }

    @Override
    public void onServiceRequestSuccess(ServiceRequest serviceRequest) {
    }
}
