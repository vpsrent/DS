package com.sbload.recharge.model.account.login;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.sbload.recharge.model.CommonResponse;

public class LoginResponse extends CommonResponse {

    @SerializedName("response")
    @Expose

    private LoginResponseResult responseResult;

    public LoginResponseResult getResponseResult() {
        return responseResult;
    }

    public void setResponseResult(LoginResponseResult responseResult) {
        this.responseResult = responseResult;
    }
}
