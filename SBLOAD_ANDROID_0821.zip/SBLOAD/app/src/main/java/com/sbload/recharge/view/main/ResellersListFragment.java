package com.sbload.recharge.view.main;


import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.account.ResellersListExecutive;
import com.sbload.recharge.model.Reseller;
import com.sbload.recharge.model.account.reseller.ResellerChanged;
import com.sbload.recharge.model.service.Service;
import com.sbload.recharge.view.BaseFragment;

import java.util.ArrayList;

public class ResellersListFragment extends BaseFragment implements View.OnClickListener,
        ResellersRecyclerViewAdapter.ResellerRecyclerItemEventListener,
        ResellersListExecutive.ResellersListDisplay, ResellerChanged {

    public ArrayList<Service> services = new ArrayList<>();
    private RecyclerView resellersRecyclerView;
    private ResellersRecyclerViewAdapter resellersAdapter = new ResellersRecyclerViewAdapter(this);
    private ResellersListExecutive executive;

    public ResellersListFragment() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_resellers_list, container, false);

        //
        // Define controls
        //

        resellersRecyclerView = view.findViewById(R.id.recycler_resellers);
        resellersRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        resellersRecyclerView.setAdapter(resellersAdapter);

        //
        // Define Events
        //

        view.findViewById(R.id.btn_back).setOnClickListener(this);

        executive = new ResellersListExecutive(this);
        executive.requestGetResellers();

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_back:
                popBackStack();
                break;
        }
    }

    @Override
    public void didClickEdit(Reseller reseller, int position) {
        AddResellerFragment fragment = new AddResellerFragment();
        fragment.services = services;
        fragment.reseller = reseller;
        fragment.resellerChangedInterface = this;
        addContent(fragment);
    }

    @Override
    public void onGetResellers(ArrayList<Reseller> resellers) {
        resellersAdapter.setResellers(resellers);
        resellersAdapter.notifyDataSetChanged();
    }

    @Override
    public void resellerChanged() {
        executive.requestGetResellers();
    }
}
