package com.sbload.recharge.model.account.reseller;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.BaseRequest;
import com.sbload.recharge.model.CommonResponse;
import com.sbload.recharge.utility.APIUtility;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddResellerRequest extends BaseRequest {

    private String userId;
    private String name;
    private String password;
    private String mobile;
    private String email;
    private String note;
    private String pin;
    private Integer type;
    private Integer active;

    public AddResellerRequest(String userId, String name, String password, String mobile,
                              String email, String note, String pin, Integer type, Integer active) {
        this.userId = userId;
        this.name = name;
        this.password = password;
        this.mobile = mobile;
        this.email = email;
        this.note = note;
        this.pin = pin;
        this.type = type;
        this.active = active;
    }

    public String getUserId() {
        return userId;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }

    public String getMobile() {
        return mobile;
    }

    public String getEmail() {
        return email;
    }

    public String getNote() {
        return note;
    }

    public String getPin() {
        return pin;
    }

    public Integer getType() {
        return type;
    }

    public Integer getActive() {
        return active;
    }

    public void post(final APIUtility.APIResponse<AddResellerResponse> apiResponse,
                     final CommonExecutive executive) {

        accountService.addReseller(userId, name, password, mobile, email, note, pin, type, active)
                .enqueue(new Callback<AddResellerResponse>() {
                    @Override
                    public void onResponse(Call<AddResellerResponse> call, Response<AddResellerResponse> response) {
                        if (!executive.validateResponse(response)) {
                            apiResponse.onResponse(null);
                            return;
                        }

                        apiResponse.onResponse(response.body());
                    }

                    @Override
                    public void onFailure(Call<AddResellerResponse> call, Throwable t) {
                        executive.display.showError(R.string.request_failed);
                        apiResponse.onResponse(null);
                    }
                });
    }
}
