package com.sbload.recharge.model.account.login;

import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.BaseRequest;
import com.sbload.recharge.utility.APIUtility;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GetResellerRequest extends BaseRequest {

    private String userId;

    public GetResellerRequest(String userId) {
        this.userId = userId;
    }

    public void post(final APIUtility.APIResponse<GetResellerResponse> apiResponse,
                     final CommonExecutive executive) {

        accountService.getReseller(userId).enqueue(new Callback<GetResellerResponse>() {
            @Override
            public void onResponse(Call<GetResellerResponse> call, Response<GetResellerResponse> response) {
                if (!executive.validateResponse(response)) {
                    apiResponse.onResponse(null);
                    return;
                }

                AppData.user = response.body().getReseller();
                apiResponse.onResponse(response.body());
            }

            @Override
            public void onFailure(Call<GetResellerResponse> call, Throwable t) {
                executive.display.showError(R.string.request_failed);
                apiResponse.onResponse(null);
            }
        });
    }
}
