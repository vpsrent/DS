package com.sbload.recharge.executive.payment;

import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.CommonResponse;
import com.sbload.recharge.model.Reseller;
import com.sbload.recharge.model.account.reseller.GetResellersRequest;
import com.sbload.recharge.model.account.reseller.GetResellersResponse;
import com.sbload.recharge.model.payment.AddPaymentRequest;
import com.sbload.recharge.utility.APIUtility;

import java.util.ArrayList;

public class VerifyPaymentExecutive extends CommonExecutive {
    VerifyPaymentDisplay display;

    public VerifyPaymentExecutive(VerifyPaymentDisplay display) {
        super(display);
        this.display = display;
    }

    public void displayDidLoad(AddPaymentRequest request, ArrayList<Reseller> resellers) {
        Reseller reseller = resellers.get(request.getToUserId());
        String resellerName = "Reseller Name:  " + reseller.getUserName();
        String amount = "Amount:  " + request.getAmount();
        String type = "Type:  " + (request.getType() == 0 ? "Payment" : "Return");
        display.showConfirmations(resellerName, amount, type);
    }

    public void didPressSubmit() {
        AddPaymentRequest paymentRequest = display.getAddPaymentRequest();
        int validateString = validateAddPaymentRequest(paymentRequest);
        if (validateString != R.string.input_validate) {
            display.showError(validateString);
            return;
        }

        display.showLoading(true);
        paymentRequest.post(new APIUtility.APIResponse<CommonResponse>() {
            @Override
            public void onResponse(CommonResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }

                display.showSuccess(R.string.add_payment_success);
                display.onSuccessProcessPayment();
            }
        }, this);
    }

    public int validateAddPaymentRequest(AddPaymentRequest request) {
        if (request.getPin().isEmpty()) {
            return R.string.empty_pin;
        }

        return R.string.input_validate;
    }

    public interface VerifyPaymentDisplay extends CommonDisplay {
        AddPaymentRequest getAddPaymentRequest();
        void onSuccessProcessPayment();
        void showConfirmations(String resellerName, String amount, String type);
    }
}
