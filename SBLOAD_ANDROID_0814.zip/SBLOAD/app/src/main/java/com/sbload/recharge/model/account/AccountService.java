package com.sbload.recharge.model.account;

import com.sbload.recharge.model.CommonResponse;
import com.sbload.recharge.model.account.login.LoginResponse;
import com.sbload.recharge.model.account.reseller.AddResellerResponse;
import com.sbload.recharge.model.account.reseller.GetResellersRequest;
import com.sbload.recharge.model.account.reseller.GetResellersResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface AccountService {

    @FormUrlEncoded
    @POST("user/domain")
    Call<CommonResponse> domain(@Field("domain") String domain);

    @FormUrlEncoded
    @POST("user/forgot_password")
    Call<CommonResponse> forgotPassword(@Field("username") String username);

    @FormUrlEncoded
    @POST("user/change_password")
    Call<CommonResponse> changePassword(@Field("username") String usename,
                                       @Field("password") String password,
                                       @Field("new_password") String newPassword);

    @FormUrlEncoded
    @POST("user/login")
    Call<LoginResponse> login(@Field("device_id") String deviceId,
                              @Field("username") String name,
                              @Field("password") String password);

    @FormUrlEncoded
    @POST("user/verify_pin")
    Call<CommonResponse> verifyPIN(@Field("device_id") String deviceId,
                                   @Field("user_id") String userId,
                                   @Field("pin") String pin);

    @FormUrlEncoded
    @POST("user/change_pin")
    Call<CommonResponse> changePIN(@Field("username") String userName,
                                   @Field("password") String password,
                                   @Field("new_pin") String pin);

    @FormUrlEncoded
    @POST("user/register")
    Call<CommonResponse> register(@Field("device_id") String deviceId,
                                  @Field("username") String name,
                                  @Field("mobile") String mobile,
                                  @Field("email") String email);

    @FormUrlEncoded
    @POST("user/add_reseller")
    Call<AddResellerResponse> addReseller(@Field("user_id") String userId,
                                          @Field("username") String name,
                                          @Field("password") String password,
                                          @Field("mobile") String mobile,
                                          @Field("email") String email,
                                          @Field("note") String note,
                                          @Field("pin") String pin,
                                          @Field("ptype") Integer pType,
                                          @Field("active") Integer active);

    @FormUrlEncoded
    @POST("user/edit_reseller")
    Call<AddResellerResponse> editReseller(@Field("user_id") String userId,
                                           @Field("username") String name,
                                           @Field("password") String password,
                                           @Field("new_password") String newPassword,
                                           @Field("mobile") String mobile,
                                           @Field("email") String email,
                                           @Field("note") String note,
                                           @Field("pin") String pin,
                                           @Field("new_pin") String newPin,
                                           @Field("ptype") Integer pType,
                                           @Field("active") Integer active);

    @FormUrlEncoded
    @POST("user/get_resellers")
    Call<GetResellersResponse> getResellers(@Field("user_id") String userId);
}
