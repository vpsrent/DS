package com.sbload.recharge.model.service;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.sbload.recharge.model.CommonResponse;

public class ServiceRequestResponse extends CommonResponse {

    @SerializedName("response")
    @Expose

    private ServiceRequest serviceRequest;

    public ServiceRequest getServiceRequest() {
        return serviceRequest;
    }
}
