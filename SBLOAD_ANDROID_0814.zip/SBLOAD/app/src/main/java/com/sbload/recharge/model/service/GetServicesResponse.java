package com.sbload.recharge.model.service;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.sbload.recharge.model.CommonResponse;

import java.util.ArrayList;

public class GetServicesResponse extends CommonResponse {

    @SerializedName("response")
    @Expose

    private ArrayList<Service> services;

    public ArrayList<Service> getServices() {
        return services;
    }

    public void setServices(ArrayList<Service> services) {
        this.services = services;
    }
}
