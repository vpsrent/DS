package com.sbload.recharge.view.main.request;

import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatSpinner;
import android.support.v7.widget.AppCompatTextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import com.google.gson.Gson;
import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.executive.service.ServiceRequestExecutive;
import com.sbload.recharge.model.account.pin.VerifyPINRequest;
import com.sbload.recharge.model.service.Service;
import com.sbload.recharge.model.service.ServiceRequest;
import com.sbload.recharge.model.service.ServiceRequestRequest;
import com.sbload.recharge.utility.CommonUtility;
import com.sbload.recharge.view.BaseFragment;

public class Service3264RequestFragment extends BaseFragment implements View.OnClickListener, ServiceRequestExecutive.ServiceRequestDisplay {
    private static final String ARG_SERVICE = "arg_service";
    private AppCompatTextView titleTextView;
    private Service service;
    private ServiceRequestExecutive requestExecutive;
    private AppCompatEditText amountEditText, numberEditText;
    private AppCompatSpinner cashTypeSpinner;

    public Service3264RequestFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        service = null;
        if (getArguments() != null) {
            String serviceJson = getArguments().getString(ARG_SERVICE);
            service = new Gson().fromJson(serviceJson, Service.class);
        }
    }

    public static Service3264RequestFragment newInstance(String serviceSerialized) {
        Service3264RequestFragment fragment = new Service3264RequestFragment();
        Bundle args = new Bundle();
        args.putString(ARG_SERVICE, serviceSerialized);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public String getTagName() {
        return Service3264RequestFragment.class.getCanonicalName();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_service3264_request, container, false);

        //
        // Bind controls
        //

        cashTypeSpinner = view.findViewById(R.id.spinner_cash_type);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getActivity(),
                R.array.cash_type_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cashTypeSpinner.setAdapter(adapter);
        titleTextView = view.findViewById(R.id.txt_title);
        titleTextView.setText(service.getName() + " " + getResources().getString(R.string.request));
        amountEditText = view.findViewById(R.id.edit_amount);
        numberEditText = view.findViewById(R.id.edit_mobile);

        //
        // Define Events
        //

        view.findViewById(R.id.btn_send).setOnClickListener(this);
        view.findViewById(R.id.btn_back).setOnClickListener(this);
        requestExecutive = new ServiceRequestExecutive(this);

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_back:
                popBackStack();
                break;
            case R.id.btn_send:
                if (requestExecutive.validateParameters()) {
                    VerifyRequestFragment fragment = new VerifyRequestFragment();
                    fragment.dashboardItem = service;
                    fragment.requestExecutive = requestExecutive;
                    addContent(fragment);
                }
                break;
        }
    }

    @Override
    public ServiceRequestRequest getServiceRequestRequest() {
        return new ServiceRequestRequest(AppData.user.getUserId(), service.getServiceId(),
                numberEditText.getText().toString(),
                CommonUtility.stringToFloat(amountEditText.getText().toString()),
                cashTypeSpinner.getSelectedItemPosition(), -1, -1);
    }

    @Override
    public VerifyPINRequest getVerifyPINRequest() {
        return null;
    }

    @Override
    public void onServiceRequestSuccess(ServiceRequest serviceRequest) {

    }
}
