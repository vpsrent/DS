package com.sbload.recharge.executive;

import com.sbload.recharge.R;
import com.sbload.recharge.model.CommonResponse;

import retrofit2.Response;

public class CommonExecutive {
    public CommonDisplay display;

    public CommonExecutive(CommonDisplay display) {
        this.display = display;
    }

    public boolean validateResponse(Response response) {
        if (!response.isSuccessful()) {
            display.showError(R.string.request_failed);
            return false;
        }
        CommonResponse responseBody = ((Response<CommonResponse>) response).body();
        if (responseBody == null ||
                responseBody.getStatus().getCode() != 0) {
            display.showError(responseBody.getStatus().getMessage());
            return false;
        }
        return true;
    }

    public interface CommonDisplay {
        void showLoading(boolean isShow);
        void showError(String message);
        void showError(int message);
        void showSuccess(int message);
    }
}
