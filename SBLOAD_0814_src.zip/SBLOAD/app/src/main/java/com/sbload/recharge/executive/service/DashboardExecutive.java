package com.sbload.recharge.executive.service;

import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.service.DashboardItem;
import com.sbload.recharge.model.service.GetServicesRequest;
import com.sbload.recharge.model.service.GetServicesResponse;
import com.sbload.recharge.model.service.Service;
import com.sbload.recharge.utility.APIUtility;

import java.util.ArrayList;

public class DashboardExecutive extends CommonExecutive {
    DashboardDisplay display;
    ArrayList<Service> services = new ArrayList<>();

    public DashboardExecutive(DashboardDisplay display) {
        super(display);
        this.display = display;
    }

    public void requestGetServices() {
        GetServicesRequest request = new GetServicesRequest(AppData.user.getUserId());

        display.showLoading(true);
        request.post(new APIUtility.APIResponse<GetServicesResponse>() {
            @Override
            public void onResponse(GetServicesResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }

                ArrayList<DashboardItem> dashboardItems = new ArrayList<>();
                services.clear();
                for (Service service : response.getServices()) {
                    dashboardItems.add(service);
                    services.add(service);
                }
                dashboardItems.add(new DashboardItem(0, "Package", "package"));
                dashboardItems.add(new DashboardItem(1, "Payments", "billpay"));
                dashboardItems.add(new DashboardItem(2, "History", "history"));
                dashboardItems.add(new DashboardItem(3, "Report", "report"));
                dashboardItems.add(new DashboardItem(4, "Logs", "report"));
                display.onGetServices(dashboardItems);
            }
        }, this);
    }

    public ArrayList<Service> getServices() {
        return services;
    }

    public interface DashboardDisplay extends CommonExecutive.CommonDisplay {
        public void onGetServices(ArrayList<DashboardItem> services);
    }
}
