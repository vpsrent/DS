package com.sbload.recharge.model.account.reseller;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.BaseRequest;
import com.sbload.recharge.utility.APIUtility;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditResellerRequest extends BaseRequest {

    private String userId;
    private String name;
    private String password;
    private String newPassword;
    private String mobile;
    private String email;
    private String note;
    private String pin;
    private String newPin;
    private Integer type;
    private Integer active;

    public EditResellerRequest(String userId, String name, String password, String newPassword,
                               String mobile, String email, String note, String pin, String newPin,
                               Integer type, Integer active) {

        this.userId = userId;
        this.name = name;
        this.password = password;
        this.newPassword = newPassword;
        this.mobile = mobile;
        this.email = email;
        this.note = note;
        this.pin = pin;
        this.newPin = newPin;
        this.type = type;
        this.active = active;
    }

    public String getUserId() {
        return userId;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public String getMobile() {
        return mobile;
    }

    public String getEmail() {
        return email;
    }

    public String getNote() {
        return note;
    }

    public String getPin() {
        return pin;
    }

    public String getNewPin() {
        return newPin;
    }

    public Integer getType() {
        return type;
    }

    public Integer getActive() {
        return active;
    }

    public void post(final APIUtility.APIResponse<AddResellerResponse> apiResponse,
                     final CommonExecutive executive) {

        accountService.editReseller(userId, name, password, newPassword, mobile, email, note, pin,
                newPin, type, active)
                .enqueue(new Callback<AddResellerResponse>() {
                    @Override
                    public void onResponse(Call<AddResellerResponse> call, Response<AddResellerResponse> response) {
                        if (!executive.validateResponse(response)) {
                            apiResponse.onResponse(null);
                            return;
                        }

                        apiResponse.onResponse(response.body());
                    }

                    @Override
                    public void onFailure(Call<AddResellerResponse> call, Throwable t) {
                        executive.display.showError(R.string.request_failed);
                        apiResponse.onResponse(null);
                    }
                });
    }
}
