package com.sbload.recharge.utility;

import com.sbload.recharge.model.account.AccountService;
import com.sbload.recharge.model.payment.PaymentService;
import com.sbload.recharge.model.support.SupportService;

public class APIUtility {
    static final String BASE_URL = "https://sbload.xyz/sbload/api/v1/";
//    static final String BASE_URL = "http://192.168.6.2/sbload/api/v1/";

    public static AccountService getAccountService() {
        return RetrofitClient.getClient(BASE_URL).create(AccountService.class);
    }

    public static PaymentService getPaymentService() {
        return RetrofitClient.getClient(BASE_URL).create(PaymentService.class);
    }

    public static SupportService getSupportService() {
        return RetrofitClient.getClient(BASE_URL).create(SupportService.class);
    }

    public interface APIResponse<T> {
        void onResponse(T response);
    }
}
