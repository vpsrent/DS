package com.sbload.recharge.view.main.request;

import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatRadioButton;
import android.support.v7.widget.AppCompatSpinner;
import android.support.v7.widget.AppCompatTextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import com.google.gson.Gson;
import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.executive.service.Service512RequestExecutive;
import com.sbload.recharge.executive.service.ServiceRequestExecutive;
import com.sbload.recharge.model.account.pin.VerifyPINRequest;
import com.sbload.recharge.model.region.Country;
import com.sbload.recharge.model.region.Operator;
import com.sbload.recharge.model.service.Service;
import com.sbload.recharge.model.service.ServiceRequest;
import com.sbload.recharge.model.service.ServiceRequestRequest;
import com.sbload.recharge.utility.CommonUtility;
import com.sbload.recharge.view.BaseFragment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Service512RequestFragment extends BaseFragment implements View.OnClickListener, Service512RequestExecutive.Service512RequestDisplay, ServiceRequestExecutive.ServiceRequestDisplay {

    private static final String ARG_SERVICE = "arg_service";
    private AppCompatTextView titleTextView;
    private AppCompatEditText amountEditText, numberEditText;
    private AppCompatRadioButton prepaidRadioButton;
    private Service service;

    private AppCompatSpinner countrySpinner, operatorSpinner;
    private ServiceRequestExecutive requestExecutive;
    ArrayAdapter<String> adapter, operatorAdapter;
    private Service512RequestExecutive executive;

    public Service512RequestFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        service = null;
        if (getArguments() != null) {
            String serviceJson = getArguments().getString(ARG_SERVICE);
            service = new Gson().fromJson(serviceJson, Service.class);
        }
    }

    public static Service512RequestFragment newInstance(String serviceSerialized) {
        Service512RequestFragment fragment = new Service512RequestFragment();
        Bundle args = new Bundle();
        args.putString(ARG_SERVICE, serviceSerialized);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public String getTagName() {
        return Service512RequestFragment.class.getCanonicalName();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_service512_request, container, false);

        //
        // Bind controls
        //

        countrySpinner = view.findViewById(R.id.spinner_country);
        String[] strings = getResources().getStringArray(R.array.country_array);
        List<String> items = new ArrayList<>(Arrays.asList(strings));
        adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, items);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        countrySpinner.setAdapter(adapter);
        operatorSpinner = view.findViewById(R.id.spinner_operator);
        strings = getResources().getStringArray(R.array.operator_array);
        List<String> operatorItems = new ArrayList<>(Arrays.asList(strings));
        operatorAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, operatorItems);
        operatorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        operatorSpinner.setAdapter(operatorAdapter);
        titleTextView = view.findViewById(R.id.txt_title);
        titleTextView.setText(service.getName() + " " + getResources().getString(R.string.request));
        amountEditText = view.findViewById(R.id.edit_amount);
        numberEditText = view.findViewById(R.id.edit_mobile);
        prepaidRadioButton = view.findViewById(R.id.radio_prepaid);

        //
        // Define Events
        //

        countrySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectCountryDropDown(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        view.findViewById(R.id.btn_send).setOnClickListener(this);
        view.findViewById(R.id.btn_back).setOnClickListener(this);

        executive = new Service512RequestExecutive(this);
        executive.getCountries();
        requestExecutive = new ServiceRequestExecutive(this);

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_back:
                popBackStack();
                break;
            case R.id.btn_send:
                if (requestExecutive.validateParameters()) {
                    VerifyRequestFragment fragment = new VerifyRequestFragment();
                    fragment.dashboardItem = service;
                    fragment.requestExecutive = requestExecutive;
                    addContent(fragment);
                }
                break;
        }
    }

    public void selectCountryDropDown(int position) {
        executive.selectCountry(position);
    }

    @Override
    public void didGetOperators(ArrayList<Operator> operators) {
        requestExecutive.setOperators(operators);
        updateOperators(operators);
    }

    @Override
    public void didGetCountries(ArrayList<Country> countries) {
        requestExecutive.setCountries(countries);
        updateCountries(countries);
    }

    @Override
    public void selectCountry(int position) {
        countrySpinner.setSelection(position);
        executive.selectCountry(position);
    }

    public void updateCountries(ArrayList<Country> countries) {
        adapter.clear();
        if (countries != null){

            for (Country country : countries) {
                adapter.insert(country.getName(), adapter.getCount());
            }
        }

        adapter.notifyDataSetChanged();
    }

    public void updateOperators(ArrayList<Operator> operators) {
        operatorAdapter.clear();

        if (operators != null){

            for (Operator operator : operators) {
                operatorAdapter.insert(operator.getTitle(), operatorAdapter.getCount());
            }
        }

        adapter.notifyDataSetChanged();
    }

    @Override
    public ServiceRequestRequest getServiceRequestRequest() {
        return new ServiceRequestRequest(AppData.user.getUserId(), service.getServiceId(),
                numberEditText.getText().toString(),
                CommonUtility.stringToFloat(amountEditText.getText().toString()),
                prepaidRadioButton.isChecked() ? 0 : 1, countrySpinner.getSelectedItemPosition(),
                operatorSpinner.getSelectedItemPosition());
    }

    @Override
    public VerifyPINRequest getVerifyPINRequest() {
        return null;
    }

    @Override
    public void onServiceRequestSuccess(ServiceRequest serviceRequest) {
    }
}
