package com.sbload.recharge.view.container;

import android.os.Bundle;

import com.google.gson.Gson;
import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.common.Common;
import com.sbload.recharge.executive.container.ContainerExecutive;
import com.sbload.recharge.model.service.DashboardItem;
import com.sbload.recharge.model.service.Service;
import com.sbload.recharge.view.BaseFragment;
import com.sbload.recharge.view.main.AboutUsFragment;
import com.sbload.recharge.view.main.AddResellerFragment;
import com.sbload.recharge.view.account.ChangePINFragment;
import com.sbload.recharge.view.account.ChangePasswordFragment;
import com.sbload.recharge.view.main.DashboardFragment;
import com.sbload.recharge.view.main.OpenTicketsFragment;
import com.sbload.recharge.view.main.ResellersListFragment;
import com.sbload.recharge.view.main.history.ActivityLogsFragment;
import com.sbload.recharge.view.main.history.HistoryFragment;
import com.sbload.recharge.view.main.history.PaymentHistoryFragment;
import com.sbload.recharge.view.main.history.ReportServiceFragment;
import com.sbload.recharge.view.main.payment.AddPaymentFragment;
import com.sbload.recharge.view.main.request.Service3264RequestFragment;
import com.sbload.recharge.view.main.request.Service512RequestFragment;
import com.sbload.recharge.view.main.request.Service8PackageRequestFragment;
import com.sbload.recharge.view.main.request.Service8RequestFragment;
import com.sbload.recharge.view.main.request.ServiceComingSoonFragment;
import com.sbload.recharge.view.sidemenu.SideMenuFragment;

public class ContainerActivity extends BaseSlidingActivity implements ContainerExecutive.ContainerDisplay {
    private BaseFragment contentFragment;

    private SideMenuFragment menuFragment;
    private ContainerExecutive executive;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_container);

        //
        // Create executive
        //

        executive = new ContainerExecutive(this);

        //
        // Set sliding menu view
        //

        menuFragment = new SideMenuFragment();
        menuFragment.containerExecutive = executive;
        setBehindContentView(R.layout.sliding_menu_frame);
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.menu_frame, menuFragment)
                .commit();

        //
        // Set content view
        //

        contentFragment = new DashboardFragment();
        setContentView(R.layout.activity_container);
        switchContent(contentFragment, ContainerExecutive.SideMenuItem.Home);

        //
        // Configure Slide Menu
        //

        SlidingMenu menu = getSlidingMenu();
        menu.setMode(SlidingMenu.RIGHT);
        menu.setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);
        menu.setShadowWidthRes(R.dimen.side_menu_shadow_size);
        menu.setShadowDrawable(R.drawable.shadow);
        menu.setBehindOffset((int) (Common.screenSize(this).x * 0.35));
        menu.setFadeDegree(0.35f);
    }

    public void switchContent(BaseFragment fragment, ContainerExecutive.SideMenuItem item) {
        contentFragment = fragment;
        contentFragment.containerExecutive = executive;
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.container, fragment)
                .commit();
        getSlidingMenu().showContent();
    }

    public void addContent(BaseFragment fragment) {
        contentFragment = fragment;
        contentFragment.containerExecutive = executive;
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.container, fragment)
                .addToBackStack(fragment.getTagName())
                .commit();
    }

    @Override
    public void selectSideMenuItem(ContainerExecutive.SideMenuItem item) {
        BaseFragment newContent = null;
        switch (item) {
            case Home:
                newContent = new DashboardFragment();
                break;
            case AddPayments:
                newContent = new AddPaymentFragment();
                break;
            case ChangePassword:
                newContent = new ChangePasswordFragment();
                break;
            case ChangePIN:
                newContent = new ChangePINFragment();
                break;
            case OpenTickets:
                newContent = new OpenTicketsFragment();
                break;
            case AboutUs:
                newContent = new AboutUsFragment();
                break;
            case LogOut:
                AppData.user = null;
                finish();
                break;
        }

        if (newContent != null) {
            menuFragment.setHighLightItem(item);
            switchContent(newContent, item);
        }
    }

    @Override
    public void didPressDashboardButton(ContainerExecutive.DashboardButton dashboardButton, String jsonSerialized) {
        BaseFragment addFragment = null;
        switch (dashboardButton) {
            case AddReseller:
                addFragment = new AddResellerFragment();
                break;
            case EditReseller:
                addFragment = AddResellerFragment.newInstance(jsonSerialized);
                break;
            case ResellersList:
                addFragment = new ResellersListFragment();
                break;
        }

        if (addFragment != null) {
            addContent(addFragment);
        }
    }

    @Override
    public void didPressServiceItem(Service service) {
        BaseFragment addFragment = null;
        switch (service.getType()) {
            case 1:
            case 4:
                addFragment = ServiceComingSoonFragment.newInstance(new Gson().toJson(service));
                break;
            case 2:
            case 8:
            case 16:
                addFragment = Service8RequestFragment.newInstance(new Gson().toJson(service));
                break;
            case 32:
            case 64:
            case 128:
            case 256:
            case 1024:
                addFragment = Service3264RequestFragment.newInstance(new Gson().toJson(service));
                break;
            case 512:
                addFragment = Service512RequestFragment.newInstance(new Gson().toJson(service));
                break;
        }

        if (addFragment != null) {
            addContent(addFragment);
        }
    }

    @Override
    public void didPressDashboardItem(DashboardItem dashboardItem) {
        BaseFragment addFragment = null;
        switch (dashboardItem.getServiceId()) {
            case 0:
                addFragment = Service8PackageRequestFragment.newInstance(new Gson().toJson(dashboardItem));
                break;
            case 1:
                addFragment = new PaymentHistoryFragment();
                break;
            case 2:
                addFragment = new HistoryFragment();
                break;
            case 3:
                addFragment = new ReportServiceFragment();
                break;
            case 4:
                addFragment = new ActivityLogsFragment();
                break;

        }

        if (addFragment != null) {
            addContent(addFragment);
        }
    }

    @Override
    public void showSideMenu() {
        getSlidingMenu().showMenu();
    }
}
