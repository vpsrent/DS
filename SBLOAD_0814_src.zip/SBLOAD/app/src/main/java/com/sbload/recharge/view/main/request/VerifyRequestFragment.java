package com.sbload.recharge.view.main.request;

import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatTextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.executive.service.ServiceRequestExecutive;
import com.sbload.recharge.model.account.pin.VerifyPINRequest;
import com.sbload.recharge.model.service.DashboardItem;
import com.sbload.recharge.model.service.Service;
import com.sbload.recharge.model.service.ServiceRequest;
import com.sbload.recharge.model.service.ServiceRequestRequest;
import com.sbload.recharge.utility.StringUtility;
import com.sbload.recharge.view.BaseFragment;

public class VerifyRequestFragment extends BaseFragment implements View.OnClickListener, ServiceRequestExecutive.ServiceRequestDisplay {

    public ServiceRequestExecutive requestExecutive;
    public DashboardItem dashboardItem;
    AppCompatTextView numberTextView, amountTextView, costTextView, typeTextView;
    AppCompatEditText editPIN;

    @Override
    public String getTagName() {
        return VerifyRequestFragment.class.getCanonicalName();
    }

    public VerifyRequestFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_verify_request, container, false);

        //
        // Bind Controls
        //

        numberTextView = view.findViewById(R.id.txt_number);
        amountTextView = view.findViewById(R.id.txt_amount);
        costTextView = view.findViewById(R.id.txt_cost);
        typeTextView = view.findViewById(R.id.txt_type);
        editPIN = view.findViewById(R.id.edit_pin);

        //
        // Define Events
        //

        view.findViewById(R.id.btn_back).setOnClickListener(this);
        view.findViewById(R.id.btn_send).setOnClickListener(this);

        requestExecutive.setDisplay(this);

        //
        // Load values
        //

        loadValues();

        return view;
    }

    private void loadValues() {
        ServiceRequestRequest request = requestExecutive.getRequest();
        numberTextView.setText("Number:  " + request.getNumber());
        amountTextView.setText(String.format("Amount:  %.2f", request.getAmount()));
        costTextView.setText(String.format("Cost:  %.2f", request.getAmount()));
        int type = 0;
        if (dashboardItem instanceof Service) {
            Service service = (Service)dashboardItem;
            switch (service.getType()) {
                case 2:
                case 8:
                case 16:
                case 512:
                    type = request.getType() == 0 ? R.string.prepaid : R.string.postpaid;
                    break;
                case 32:
                case 64:
                case 128:
                case 256:
                case 1024:
                    if (request.getType() == 0) {
                        type = R.string.cash_in;
                    }
                    else if (request.getType() == 1) {
                        type = R.string.cash_out;
                    }
                    else if (request.getType() == 2) {
                        type = R.string.send_money;
                    }
                    else {
                        type = R.string.payment;
                    }
                    break;
            }
        }
        else {
            type = request.getType() == 0 ? R.string.prepaid : R.string.postpaid;
        }
        typeTextView.setText("Type:  " + getResources().getString(type));
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_back:
                popBackStack();
                break;
            case R.id.btn_send:
                requestExecutive.verifyCode();
                break;
        }
    }

    @Override
    public ServiceRequestRequest getServiceRequestRequest() {
        return null;
    }

    @Override
    public VerifyPINRequest getVerifyPINRequest() {
        return new VerifyPINRequest(StringUtility.deviceId(getActivity().getApplicationContext()),
                AppData.user.getUserId(), editPIN.getText().toString());
    }

    @Override
    public void onServiceRequestSuccess(ServiceRequest serviceRequest) {
        addContent(new RequestSuccessFragment());
    }
}
