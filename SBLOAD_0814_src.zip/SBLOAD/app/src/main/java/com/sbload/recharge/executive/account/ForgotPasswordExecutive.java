package com.sbload.recharge.executive.account;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.CommonResponse;
import com.sbload.recharge.model.account.forgotpassword.ForgotPasswordRequest;
import com.sbload.recharge.utility.APIUtility;

public class ForgotPasswordExecutive extends CommonExecutive {
    ForgotPasswordDisplay display;

    public ForgotPasswordExecutive(ForgotPasswordDisplay display) {
        super(display);
        this.display = display;
    }

    public void requestForgotPassword() {
        ForgotPasswordRequest request = display.getForgotPasswordRequest();
        if (request == null) {
            return;
        }

        int validateString = validateForgotPasswordRequest(request);
        if (validateString != R.string.input_validate) {
            display.showError(validateString);
            return;
        }

        display.showLoading(true);
        request.post(new APIUtility.APIResponse<CommonResponse>() {
            @Override
            public void onResponse(CommonResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }
                display.showSuccess(R.string.reset_password_success);
                display.passwordReset();
            }
        }, this);
    }

    public int validateForgotPasswordRequest(ForgotPasswordRequest request) {
        if (request.getUsername().isEmpty()) {
            return R.string.empty_user_name;
        }

        return R.string.input_validate;
    }

    public interface ForgotPasswordDisplay extends CommonExecutive.CommonDisplay {
        public void passwordReset();
        public ForgotPasswordRequest getForgotPasswordRequest();
    }
}
