package com.sbload.recharge.view.main.payment;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatSpinner;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import com.sbload.recharge.R;
import com.sbload.recharge.common.AppData;
import com.sbload.recharge.executive.payment.AddPaymentExecutive;
import com.sbload.recharge.model.Reseller;
import com.sbload.recharge.model.payment.AddPaymentRequest;
import com.sbload.recharge.utility.CommonUtility;
import com.sbload.recharge.view.BaseFragment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AddPaymentFragment extends BaseFragment implements AddPaymentExecutive.AddPaymentDisplay {
    private AppCompatSpinner resellerSpinner, paymentTypeSpinner;
    private AppCompatEditText amountEditText;
    ArrayAdapter<String> adapter, typeAdapter;

    private AddPaymentExecutive executive;

    public AddPaymentFragment() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_payment, container, false);

        //
        // Bind controls
        //

        resellerSpinner = view.findViewById(R.id.spinner_reseller);
        String[] strings = getResources().getStringArray(R.array.country_array);
        List<String> items = new ArrayList<>(Arrays.asList(strings));
        adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, items);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        resellerSpinner.setAdapter(adapter);

        paymentTypeSpinner = view.findViewById(R.id.spinner_payment_type);
        strings = getResources().getStringArray(R.array.payment_type_array);
        List<String> typeItems = new ArrayList<>(Arrays.asList(strings));
        typeAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, typeItems);
        typeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        paymentTypeSpinner.setAdapter(typeAdapter);
        amountEditText = view.findViewById(R.id.edit_amount);

        //
        // Define Events
        //

        view.findViewById(R.id.btn_submit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                executive.didPressSubmit();
            }
        });

        view.findViewById(R.id.btn_side_menu).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                containerExecutive.didPressSideMenuButton();
            }
        });

        executive = new AddPaymentExecutive(this);
        executive.getResellers();

        return view;
    }

    @Override
    public void onGetResellers(ArrayList<Reseller> resellers) {
        adapter.clear();
        if (resellers != null){

            for (Reseller reseller : resellers) {
                adapter.insert(reseller.getUserName(), adapter.getCount());
            }
        }

        adapter.notifyDataSetChanged();
    }

    @Override
    public AddPaymentRequest getAddPaymentRequest() {
        return new AddPaymentRequest(Integer.valueOf(AppData.user.getUserId()),
                resellerSpinner.getSelectedItemPosition(),
                CommonUtility.stringToFloat(amountEditText.getText().toString(), -1.f),
                paymentTypeSpinner.getSelectedItemPosition(), "");
    }

    @Override
    public void gotoPaymentConfirm(AddPaymentRequest request, ArrayList<Reseller> resellers) {
        VerifyPaymentFragment verifyPaymentFragment = new VerifyPaymentFragment();
        verifyPaymentFragment.request = request;
        verifyPaymentFragment.resellers = resellers;
        addContent(verifyPaymentFragment);
    }
}
