package com.sbload.recharge.view.main;

import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sbload.recharge.R;
import com.sbload.recharge.model.Reseller;

import java.util.ArrayList;

public class ResellersRecyclerViewAdapter extends RecyclerView.Adapter<ResellersRecyclerViewAdapter.ViewHolder> {
    ResellerRecyclerItemEventListener listener;

    public void setResellers(ArrayList<Reseller> resellers) {
        this.resellers = resellers;
    }

    private ArrayList<Reseller> resellers = new ArrayList<>();
    ResellersRecyclerViewAdapter(ResellerRecyclerItemEventListener listener) {
        super();
        this.listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_reseller, parent, false);
        return new ResellersRecyclerViewAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final Reseller reseller = resellers.get(position);
        holder.userNameTextView.setText(reseller.getUserName());
        holder.balanceTextView.setText(reseller.getBalance());
        holder.statusTextView.setText(reseller.getStatus() + "");
        holder.editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.didClickEdit(reseller, position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return resellers.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        final AppCompatTextView userNameTextView, balanceTextView, statusTextView;
        final AppCompatTextView editButton;

        ViewHolder(View view) {
            super(view);

            userNameTextView = view.findViewById(R.id.text_view_user_name);
            balanceTextView = view.findViewById(R.id.text_view_balance);
            statusTextView = view.findViewById(R.id.text_view_status);
            editButton = view.findViewById(R.id.btn_edit);
        }
    }

    public interface ResellerRecyclerItemEventListener {
        void didClickEdit(Reseller reseller, int position);
    }
}