package com.sbload.recharge.model.service;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ServiceRequest {
    @SerializedName("id")
    @Expose
    private Integer requestId;

    @SerializedName("cid")
    @Expose
    private Integer countryId;

    @SerializedName("oid")
    @Expose
    private Integer operatorId;

    @SerializedName("sender")
    @Expose
    private Integer sender;

    @SerializedName("receiver")
    @Expose
    private String receiver;

    @SerializedName("amount")
    @Expose
    private Integer amount;

    @SerializedName("type")
    @Expose
    private Integer type;

    @SerializedName("service_id")
    @Expose
    private Integer serviceId;

    @SerializedName("cost")
    @Expose
    private float cost;

    @SerializedName("cost2")
    @Expose
    private float cost2;

    @SerializedName("cost3")
    @Expose
    private float cost3;

    @SerializedName("cost4")
    @Expose
    private float cost4;

    @SerializedName("cost5")
    @Expose
    private float cost5;

    @SerializedName("bal")
    @Expose
    private float balance;

    @SerializedName("bal2")
    @Expose
    private float balance2;

    @SerializedName("bal3")
    @Expose
    private float balance3;

    @SerializedName("bal4")
    @Expose
    private float balance4;

    @SerializedName("bal5")
    @Expose
    private float balance5;

    @SerializedName("rs2")
    @Expose
    private int rs2;

    @SerializedName("rs3")
    @Expose
    private int rs3;

    @SerializedName("rs4")
    @Expose
    private int rs4;

    @SerializedName("rs5")
    @Expose
    private int rs5;

    @SerializedName("status")
    @Expose
    private int status;

    @SerializedName("transactionid")
    @Expose
    private String transactionId;

    @SerializedName("modem")
    @Expose
    private int modem;

    @SerializedName("api")
    @Expose
    private int api;

    @SerializedName("confirmed")
    @Expose
    private int confirmed;

    @SerializedName("token")
    @Expose
    private int token;

    @SerializedName("ip")
    @Expose
    private String ip;
}
