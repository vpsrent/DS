package com.sbload.recharge.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class History {
    @SerializedName("transaction_no")
    @Expose
    private String transactionNo;

    @SerializedName("cashType")
    @Expose
    private String cashType;

    @SerializedName("date")
    @Expose
    private String date;

    @SerializedName("amount")
    @Expose
    private float amount;

    @SerializedName("cost")
    @Expose
    private float cost;

    @SerializedName("balance")
    @Expose
    private float balance;

    @SerializedName("transaction_id")
    @Expose
    private String transactionId;

    @SerializedName("status")
    @Expose
    private Integer status;

    public History(String transactionNo, String cashType, String date, float amount,
                   float cost, float balance, String transactionId,
                   Integer status) {

        super();
        this.transactionNo = transactionNo;
        this.cashType = cashType;
        this.date = date;
        this.amount = amount;
        this.cost = cost;
        this.balance = balance;
        this.transactionId = transactionId;
        this.status = status;
    }

    public String getTransactionNo() {
        return transactionNo;
    }

    public void setTransactionNo(String transactionNo) {
        this.transactionNo = transactionNo;
    }

    public String getCashType() {
        return cashType;
    }

    public void setCashType(String cashType) {
        this.cashType = cashType;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public float getCost() {
        return cost;
    }

    public void setCost(float cost) {
        this.cost = cost;
    }

    public float getBalance() {
        return balance;
    }

    public void setBalance(float balance) {
        this.balance = balance;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
