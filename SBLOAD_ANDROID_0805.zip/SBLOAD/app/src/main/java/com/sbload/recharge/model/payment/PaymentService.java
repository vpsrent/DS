package com.sbload.recharge.model.payment;

import com.sbload.recharge.model.region.GetCountriesResponse;
import com.sbload.recharge.model.region.GetOperatorsResponse;
import com.sbload.recharge.model.service.GetServicesResponse;
import com.sbload.recharge.model.service.ServiceRequestResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface PaymentService {

    @FormUrlEncoded
    @POST("payment/services")
    Call<GetServicesResponse> services(@Field("user_id") String userId);

    @FormUrlEncoded
    @POST("payment/get_countries")
    Call<GetCountriesResponse> getCountries(@Field("user_id") String userId);

    @FormUrlEncoded
    @POST("payment/get_operators")
    Call<GetOperatorsResponse> getOperators(@Field("country_id") int country_id);

    @FormUrlEncoded
    @POST("payment/request_service")
    Call<ServiceRequestResponse> serviceRequest(@Field("user_id") String userId,
                                                @Field("service_id") Integer serviceId,
                                                @Field("number") String number,
                                                @Field("amount") Float amount,
                                                @Field("type") Integer type,
                                                @Field("country") Integer country,
                                                @Field("operator") Integer operator);
}
