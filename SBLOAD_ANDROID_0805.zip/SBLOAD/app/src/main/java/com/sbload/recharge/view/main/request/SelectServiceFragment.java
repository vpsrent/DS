package com.sbload.recharge.view.main.request;


import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sbload.recharge.R;
import com.sbload.recharge.model.service.DashboardItem;
import com.sbload.recharge.model.service.Service;
import com.sbload.recharge.view.BaseFragment;
import com.sbload.recharge.view.main.ServicesRecyclerViewAdapter;

import java.util.ArrayList;

public class SelectServiceFragment extends BaseFragment implements ServicesRecyclerViewAdapter.ServiceRecyclerItemEventListener, View.OnClickListener {
    private RecyclerView servicesRecyclerView;
    private ServicesRecyclerViewAdapter servicesAdapter;
    private final int recyclerSpans = 4;
    private ArrayList<Service> services = new ArrayList<>();
    public SelectServiceFragment() {
    }

    @Override
    public String getTagName() {
        return SelectServiceFragment.class.getCanonicalName();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_select, container, false);

        //
        // Bind Controls
        //

        // For the test
//        for (int index = 0; index < 4; index++) {
//            Service service = new Service();
//            service.setServiceId(index);
//            switch (index) {
//                case 0:
//                    service.setName("FlexiLoad");
//                    break;
//                case 1:
//                    service.setName("bkash");
//                    break;
//                case 2:
//                    service.setName("rocket");
//                    break;
//                case 3:
//                    service.setName("nogod");
//                    break;
//            }
//            services.add(service);
//        }
        servicesRecyclerView = view.findViewById(R.id.recycler_services);
        servicesRecyclerView.setLayoutManager(new GridLayoutManager(getActivity(), recyclerSpans));
        servicesAdapter = new ServicesRecyclerViewAdapter(getActivity(), this);
        servicesRecyclerView.setAdapter(servicesAdapter);

        //
        // Define Events
        //

        view.findViewById(R.id.btn_side_menu).setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_side_menu:
                containerExecutive.didPressSideMenuButton();
                break;
        }
    }

    @Override
    public void didClickServiceItem(DashboardItem service, int position) {
//        containerExecutive.didPressServiceRequestButton(service);
    }
}
