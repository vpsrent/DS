package com.sbload.recharge.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PaymentHistory {
    @SerializedName("wallet_balance")
    @Expose
    private float walletBalance;

    @SerializedName("paymentNote")
    @Expose
    private String paymentNote;

    @SerializedName("address")
    @Expose
    private String adress;

    @SerializedName("date")
    @Expose
    private String date;

    public PaymentHistory(float walletBalance, String paymentNote,
                          String address, String date) {

        this.walletBalance = walletBalance;
        this.paymentNote = paymentNote;
        this.adress = address;
        this.date = date;
    }

    public float getWalletBalance() {
        return walletBalance;
    }

    public void setWalletBalance(float walletBalance) {
        this.walletBalance = walletBalance;
    }

    public String getPaymentNote() {
        return paymentNote;
    }

    public void setPaymentNote(String paymentNote) {
        this.paymentNote = paymentNote;
    }

    public String getAdress() {
        return adress;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
