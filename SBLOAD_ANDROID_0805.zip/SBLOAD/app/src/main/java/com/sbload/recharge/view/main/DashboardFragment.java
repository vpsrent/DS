package com.sbload.recharge.view.main;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.payment.DashboardExecutive;
import com.sbload.recharge.model.service.DashboardItem;
import com.sbload.recharge.view.BaseFragment;

import java.util.ArrayList;

public class DashboardFragment extends BaseFragment implements View.OnClickListener, ServicesRecyclerViewAdapter.ServiceRecyclerItemEventListener, DashboardExecutive.DashboardDisplay {
    private RecyclerView servicesRecyclerView;
    private ServicesRecyclerViewAdapter servicesAdapter;
    private final int recyclerSpans = 4;
    private DashboardExecutive executive;

    public DashboardFragment() {
    }

    @Override
    public String getTagName() {
        return DashboardFragment.class.getCanonicalName();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);

        //
        // Bind Controls
        //

        servicesRecyclerView = view.findViewById(R.id.recycler_services);
        servicesRecyclerView.setLayoutManager(new GridLayoutManager(getActivity(), recyclerSpans));
        servicesAdapter = new ServicesRecyclerViewAdapter(getActivity(), this);
        servicesRecyclerView.setAdapter(servicesAdapter);

        //
        // Set Event Handler
        //

        view.findViewById(R.id.btn_side_menu).setOnClickListener(this);
        view.findViewById(R.id.btn_add_reseller).setOnClickListener(this);
        view.findViewById(R.id.btn_resellers_list).setOnClickListener(this);

        executive = new DashboardExecutive(this);
        executive.requestGetServices();

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_side_menu:
                containerExecutive.didPressSideMenuButton();
                break;
            case R.id.btn_add_reseller:
                AddResellerFragment fragment = new AddResellerFragment();
                fragment.services = executive.getServices();
                fragment.reseller = null;
                addContent(fragment);
                break;
            case R.id.btn_resellers_list:
                ResellersListFragment resellersListFragment = new ResellersListFragment();
                resellersListFragment.services = executive.getServices();
                addContent(resellersListFragment);
                break;
        }
    }

    @Override
    public void didClickServiceItem(DashboardItem service, int position) {
        containerExecutive.didPressDashboardButton(service);
    }

    @Override
    public void onGetServices(ArrayList<DashboardItem> services) {
        servicesAdapter.setServices(services);
        servicesAdapter.notifyDataSetChanged();
    }
}
