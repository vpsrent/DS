package com.sbload.recharge.view.main.history;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.container.ContainerExecutive;
import com.sbload.recharge.model.History;
import com.sbload.recharge.view.BaseFragment;

import java.util.ArrayList;

public class HistoryFragment extends BaseFragment implements View.OnClickListener, HistoriesRecyclerViewAdapter.HistoryRecyclerItemEventListener {
    private ArrayList<History> histories = new ArrayList<>();
    private RecyclerView historiesRecyclerView;
    private HistoriesRecyclerViewAdapter historiesAdapter;

    public HistoryFragment() {
    }

    @Override
    public String getTagName() {
        return HistoryFragment.class.getCanonicalName();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_history, container, false);

        historiesAdapter = new HistoriesRecyclerViewAdapter(getActivity(), this);

        //
        // Define controls
        //

        // For the test

        History history = new History("01771240000", "PrePaid", "Jul 07",
                109, 108, 35100.66f, "BD19000000554454545454",
                1);
        histories.add(history);
        history = new History("01771240000", "PrePaid", "Jul 07",
                109, 108, 35100.66f, "Failed",
                0);
        histories.add(history);
        historiesRecyclerView = view.findViewById(R.id.recycler_history);
        historiesRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        historiesAdapter.setHistories(histories);
        historiesRecyclerView.setAdapter(historiesAdapter);

        //
        // Set Event Handler
        //

        view.findViewById(R.id.btn_back).setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_back:
                popBackStack();
                break;
        }
    }

}
