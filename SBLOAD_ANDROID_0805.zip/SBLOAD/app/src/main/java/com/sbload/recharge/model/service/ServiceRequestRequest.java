package com.sbload.recharge.model.service;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.BaseRequest;
import com.sbload.recharge.utility.APIUtility;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ServiceRequestRequest extends BaseRequest {

    private String userId;
    private int serviceId;
    private String number;
    private float amount;
    private int type;
    private int country;
    private int operator;

    public ServiceRequestRequest(String userId, int serviceId, String number, float amount, int type,
                                 int country, int operator) {
        this.userId = userId;
        this.serviceId = serviceId;
        this.number = number;
        this.amount = amount;
        this.type = type;
        this.country = country;
        this.operator = operator;
    }

    public String getUserId() {
        return userId;
    }

    public int getServiceId() {
        return serviceId;
    }

    public String getNumber() {
        return number;
    }

    public float getAmount() {
        return amount;
    }

    public int getType() {
        return type;
    }

    public int getCountry() {
        return country;
    }

    public int getOperator() {
        return operator;
    }

    public void setCountry(int country) {
        this.country = country;
    }

    public void setOperator(int operator) {
        this.operator = operator;
    }

    public void post(final APIUtility.APIResponse<ServiceRequestResponse> apiResponse,
                     final CommonExecutive executive) {
        paymentService.serviceRequest(userId, serviceId, number, amount, type, country, operator).enqueue(new Callback<ServiceRequestResponse>() {
            @Override
            public void onResponse(Call<ServiceRequestResponse> call, Response<ServiceRequestResponse> response) {
                if (!executive.validateResponse(response)) {
                    apiResponse.onResponse(null);
                    return;
                }

                apiResponse.onResponse(response.body());
            }

            @Override
            public void onFailure(Call<ServiceRequestResponse> call, Throwable t) {
                executive.display.showError(R.string.request_failed);
                apiResponse.onResponse(null);
            }
        });
    }
}
