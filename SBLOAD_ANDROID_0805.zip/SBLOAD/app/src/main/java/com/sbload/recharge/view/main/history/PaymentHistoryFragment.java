package com.sbload.recharge.view.main.history;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.container.ContainerExecutive;
import com.sbload.recharge.model.PaymentHistory;
import com.sbload.recharge.view.BaseFragment;

import java.util.ArrayList;

public class PaymentHistoryFragment extends BaseFragment implements View.OnClickListener, PaymentHistoriesRecyclerViewAdapter.PaymentHistoryRecyclerItemEventListener {
    private ArrayList<PaymentHistory> histories = new ArrayList<>();
    private RecyclerView historiesRecyclerView;
    private PaymentHistoriesRecyclerViewAdapter historiesAdapter;

    public PaymentHistoryFragment() {
    }

    @Override
    public String getTagName() {
        return PaymentHistoryFragment.class.getCanonicalName();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_payment_history, container, false);

        historiesAdapter = new PaymentHistoriesRecyclerViewAdapter(getActivity(), this);

        //
        // Define controls
        //

        // For the test

        PaymentHistory history = new PaymentHistory(20000.f, "Cash Received",
                "Dubai UAE", "May 30");
        histories.add(history);
        history = new PaymentHistory(20000.f, "Cash Received",
                "Dubai UAE", "May 30");
        histories.add(history);
        historiesRecyclerView = view.findViewById(R.id.recycler_payment_history);
        historiesRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        historiesAdapter.setHistories(histories);
        historiesRecyclerView.setAdapter(historiesAdapter);

        //
        // Define Controls
        //

        view.findViewById(R.id.btn_back).setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_back:
                popBackStack();
                break;
        }
    }

}
