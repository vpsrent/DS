package com.sbload.recharge.utility;

import android.content.Context;
import android.graphics.drawable.Drawable;

import java.io.IOException;
import java.io.InputStream;

public class CommonUtility {
    public static Drawable serviceDrawableFromAssets(Context context, String logo) {
        String assetPath = "services/" + logo + ".png";
        Drawable drawable;
        try
        {
            InputStream ims = context.getAssets().open(assetPath);
            drawable = Drawable.createFromStream(ims, null);
            ims .close();
            return drawable;
        }
        catch(IOException ex)
        {
            return null;
        }
    }

    public static float stringToFloat(String str)
    {
        try
        {
            float f = Float.valueOf(str.trim()).floatValue();
            return f;
        }
        catch (NumberFormatException nfe)
        {
            return 0.f;
        }
    }


}
