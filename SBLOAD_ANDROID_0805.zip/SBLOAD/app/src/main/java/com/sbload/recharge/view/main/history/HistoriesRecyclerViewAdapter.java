package com.sbload.recharge.view.main.history;

import android.content.Context;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sbload.recharge.R;
import com.sbload.recharge.model.History;

import java.util.ArrayList;

public class HistoriesRecyclerViewAdapter extends RecyclerView.Adapter<HistoriesRecyclerViewAdapter.ViewHolder> {
    HistoryRecyclerItemEventListener listener;

    private ArrayList<History> histories = new ArrayList<>();
    private Context context;
    HistoriesRecyclerViewAdapter(Context context, HistoryRecyclerItemEventListener listener) {
        super();
        this.context = context;
        this.listener = listener;
    }


    public void setHistories(ArrayList<History> histories) {
        this.histories = histories;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_history, parent, false);
        return new HistoriesRecyclerViewAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final History history = histories.get(position);
        holder.firstRowTextView.setText(history.getTransactionNo() + "(" +
                history.getCashType() + ")");
        holder.dateTextView.setText(history.getDate());
        holder.secondRowTextView.setText(String.format("Amount: %d - Cost: %.2f - Bal: %.2f",
                (int)history.getAmount(), history.getCost(), history.getBalance()));
        holder.thirdRowTextView.setText("TrxID: " + history.getTransactionId());
        holder.statusTextView.setText(history.getStatus() == 1 ? "Success" : "Cancelled");
        if (history.getStatus() == 1) {
            holder.statusTextView.setTextColor(context.getResources().getColor(R.color.dark_green));
        }
        else {
            holder.statusTextView.setTextColor(context.getResources().getColor(R.color.dark_red));
        }
    }

    @Override
    public int getItemCount() {
        return histories.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        final AppCompatTextView firstRowTextView, dateTextView, secondRowTextView;
        final AppCompatTextView thirdRowTextView, statusTextView;

        ViewHolder(View view) {
            super(view);

            firstRowTextView = view.findViewById(R.id.txt_first_row);
            dateTextView = view.findViewById(R.id.txt_date);
            secondRowTextView = view.findViewById(R.id.txt_second_row);
            thirdRowTextView = view.findViewById(R.id.txt_third_row);
            statusTextView = view.findViewById(R.id.txt_status);
        }
    }

    public interface HistoryRecyclerItemEventListener {
//        public void didClickEdit(Reseller reseller, int position);
    }
}
