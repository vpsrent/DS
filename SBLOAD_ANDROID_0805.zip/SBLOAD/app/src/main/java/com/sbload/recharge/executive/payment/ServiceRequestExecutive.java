package com.sbload.recharge.executive.payment;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.CommonResponse;
import com.sbload.recharge.model.account.pin.VerifyPINRequest;
import com.sbload.recharge.model.region.Country;
import com.sbload.recharge.model.region.Operator;
import com.sbload.recharge.model.service.ServiceRequest;
import com.sbload.recharge.model.service.ServiceRequestRequest;
import com.sbload.recharge.model.service.ServiceRequestResponse;
import com.sbload.recharge.utility.APIUtility;

import java.util.ArrayList;

public class ServiceRequestExecutive extends CommonExecutive {
    ServiceRequestDisplay display;
    ArrayList<Country> countries = new ArrayList<>();
    ArrayList<Operator> operators = new ArrayList<>();
    ServiceRequestRequest request;

    public ServiceRequestExecutive(ServiceRequestDisplay display) {
        super(display);
        this.display = display;
    }

    public void setDisplay(ServiceRequestDisplay display) {
        this.display = display;
    }

    public ServiceRequestRequest getRequest() {
        return request;
    }

    public void setCountries(ArrayList<Country> countries) {
        this.countries = countries;
    }

    public void setOperators(ArrayList<Operator> operators) {
        this.operators = operators;
    }

    public int validateVerifyPINRequest(VerifyPINRequest request) {
        if (request.getPin().isEmpty()) {
            return R.string.empty_pin;
        }

        return R.string.input_validate;
    }

    public void verifyCode() {
        final VerifyPINRequest request = display.getVerifyPINRequest();
        if (request == null) {
            return;
        }

        int validateString = validateVerifyPINRequest(request);
        if (validateString != R.string.input_validate) {
            display.showError(validateString);
            return;
        }

        display.showLoading(true);
        request.post(new APIUtility.APIResponse<CommonResponse>() {
            @Override
            public void onResponse(CommonResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }

                requestService();
            }
        }, this);
    }

    public void requestService() {
        display.showLoading(true);
        request.post(new APIUtility.APIResponse<ServiceRequestResponse>() {
            @Override
            public void onResponse(ServiceRequestResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }
                display.onServiceRequestSuccess(response.getServiceRequest());
            }
        }, this);
    }

    public boolean validateParameters() {
        request = display.getServiceRequestRequest();

        if (request.getCountry() != -1) {
            int countryId = countries.get(request.getCountry()).getCountryId();
            request.setCountry(countryId);
        }
        if (request.getOperator() != -1) {
            int operatorId = operators.get(request.getOperator()).getOperatorId();
            request.setOperator(operatorId);
        }

        if (request == null) {
            return false;
        }

        int validateString = validateServiceRequestRequest(request);
        if (validateString != R.string.input_validate) {
            display.showError(validateString);
            return false;
        }

        return true;
    }

    public int validateServiceRequestRequest(ServiceRequestRequest request) {
        if (request.getNumber().isEmpty()) {
            return R.string.empty_phone;
        }

        if (request.getAmount() == 0) {
            return R.string.empty_amount;
        }

        return R.string.input_validate;
    }

    public interface ServiceRequestDisplay extends CommonExecutive.CommonDisplay {
        ServiceRequestRequest getServiceRequestRequest();
        VerifyPINRequest getVerifyPINRequest();
        void onServiceRequestSuccess(ServiceRequest serviceRequest);
    }
}
