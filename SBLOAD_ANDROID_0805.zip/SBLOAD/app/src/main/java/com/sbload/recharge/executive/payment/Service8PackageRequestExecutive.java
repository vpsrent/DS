package com.sbload.recharge.executive.payment;

import com.sbload.recharge.R;
import com.sbload.recharge.executive.CommonExecutive;
import com.sbload.recharge.model.region.Country;
import com.sbload.recharge.model.region.GetCountriesRequest;
import com.sbload.recharge.model.region.GetCountriesResponse;
import com.sbload.recharge.model.region.GetOperatorsRequest;
import com.sbload.recharge.model.region.GetOperatorsResponse;
import com.sbload.recharge.model.region.Operator;
import com.sbload.recharge.utility.APIUtility;

import java.util.ArrayList;

public class Service8PackageRequestExecutive extends CommonExecutive {
    Service8PackageRequestDisplay display;
    ArrayList<Country> countries = new ArrayList<>();
    ArrayList<Operator> operators = new ArrayList<>();

    public Service8PackageRequestExecutive(Service8PackageRequestDisplay display) {
        super(display);
        this.display = display;
    }

    public void getCountries() {
        GetCountriesRequest request = new GetCountriesRequest();
        display.showLoading(true);
        request.post(new APIUtility.APIResponse<GetCountriesResponse>() {
            @Override
            public void onResponse(GetCountriesResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }

                countries.clear();
                int index = 0, position = 0;
                for (Country country : response.getCountries()) {
                    countries.add(country);
                    if (country.getCountryId() == 98) {
                        position = index;
                    }
                    index = index + 1;
                }

                display.didGetCountries(countries);
                display.selectCountry(position);
            }
        }, this);
    }

    public void selectCountry(int position) {
        if (countries.size() == 0) {
            return;
        }
        int countryId = countries.get(position).getCountryId();
        GetOperatorsRequest request = new GetOperatorsRequest(countryId);
        display.showLoading(true);
        request.post(new APIUtility.APIResponse<GetOperatorsResponse>() {
            @Override
            public void onResponse(GetOperatorsResponse response) {
                display.showLoading(false);
                if (response == null) {
                    display.showError(R.string.bad_request);
                    return;
                }

                operators.clear();
                for (Operator operator : response.getOperators()) {
                    operators.add(operator);
                }

                display.didGetOperators(operators);
            }
        }, this);
    }

    public interface Service8PackageRequestDisplay extends CommonExecutive.CommonDisplay {
        void didGetOperators(ArrayList<Operator> operators);
        void didGetCountries(ArrayList<Country> countries);
        void selectCountry(int position);
    }
}
